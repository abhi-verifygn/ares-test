#!/usr/bin/env bash

echo 'Initiating dependency installations......'
echo 'This script is tested purely for ubuntu 20.04.5 version'
echo 'Make sure your system version will match the specified version'
echo '##############################################################'
path=$(realpath "${BASH_SOURCE:-$0}")
DIR_PATH=$(dirname $path)
echo 'Executing script at location:' $DIR_PATH

echo 'Current System OS release state are as follows:'

sudo lsb_release -a
echo ' '
echo '############################################################## '
echo 'use "ctrl+z" or "ctrl+c" to abort the process'
sleep 5

sudo apt update -y
sudo apt upgrade -y

echo '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>  Installing GIT > >>>>>>>>>>>>>>>>>>>>>>>>>>>>'
sudo apt install git -y
echo '.............................................................................'

echo '>>>>>>>>>>>>>>>>>>>>>>>>>>>  Installing lighttpd > >>>>>>>>>>>>>>>>>>>>>>>>>>'
sudo apt install lighttpd -y
#sudo useradd -g www www
#sudo cp ./ares/15-fastcgi-php.conf /etc/lighttpd/conf-available/15-fastcgi-php.conf
sudo chown -R www-data:www-data /var/www/html/ 
sudo chmod -R 755 /var/www/html/
#sudo cp ./ares/lighttpd.conf /etc/lighttpd/lighttpd.conf
echo '.......................................... ..................................'

echo '>>>>>>>>> Adding php(older versions) dependencies before installing >>>>>>>>>'
sudo apt install software-properties-common ca-certificates lsb-release apt-transport-https -y
echo '>>>>>>>>>>>>>>>> Adding ondrej/php repository support >>>>>>>>>>>>>>>>>>>>>>>'
sudo LC_ALL=C.UTF-8 add-apt-repository ppa:ondrej/php -y
echo '#############################################################################'
sudo apt update -y
echo '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>  Installing php5  >>>>>>>>>>>>>>>>>>>>>>>>>>>>'
sudo apt install php5.6-common -y
sudo apt install php5.6-cli -y
sudo apt install php5.6-cgi -y
sudo apt install php5.6-curl -y
sudo apt install php5.6-gd -y
sudo apt install php5.6-mysql -y
sudo apt install php5.6-xmlrpc -y
sudo apt install php5.6-xml -y
sudo apt install php5.6-mbstring -y
sudo apt install php-pear -y

echo '>>>>>>>>>>>>>>>>>>>>>>>>> Enabling lighttpd Fastcgi >>>>>>>>>>>>>>>>>>>>>>>>>'
sudo lighty-enable-mod fastcgi
sudo lighty-enable-mod fastcgi-php
echo '.............................................................................'

echo '>>>>>>>>>>>>>>>>>>>>>>>>>> Installing HTML Template >>>>>>>>>>>>>>>>>>>>>>>>>'
sudo pear install HTML_Template_IT
sudo pear channel-update pear.php.net
echo '.............................................................................'

sudo service lighttpd force-reload
echo 'Try to launch http://localhost on your webbrowser after the process'
sleep 2

echo '>>>>>>>>>>>>>>>>>>>>>> Deploying PHP info page onto server >>>>>>>>>>>>>>>>>>'
sudo cat > /var/www/html/info.php << EOF
<?php
phpinfo();
?>
EOF
echo '.............................................................................'

echo 'Ready to launch http://localhost/info.php on your webbrowser'
sleep 2
echo '.............................................................................'

echo '>>>>>>>>>>>>>>>>>>>>>>>>>>  Installing MySQL  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>'
type mysql >/dev/null 2>&1 && MYSQLP=1 || MYSQLP=0
if [[ $MYSQLP -eq 1 ]];
then
echo 'MySQL Already present, kindly crosscheck its verion'
echo 'MySQL Supported Version - 5.6 only'
sleep 5
else
echo 'MySQL Not detected, proceeding with installation.....................'
echo 'downloading mysql-5.6.46 version.................'

sudo wget https://dev.mysql.com/get/Downloads/MySQL-5.6/mysql-5.6.46-linux-glibc2.12-x86_64.tar.gz
sudo groupadd mysql
sudo useradd -g mysql mysql
sudo tar -xvf mysql-5.6.46-linux-glibc2.12-x86_64.tar.gz
sudo rm -r /usr/local/mysql
sudo rm -r /usr/local/mysql-5.6.46-linux-glibc2.12-x86_64
sudo mv mysql-5.6.46-linux-glibc2.12-x86_64 /usr/local/
sudo rm mysql-5.6.46-linux-glibc2.12-x86_64.tar.gz
cd /usr/local
sudo mv mysql-5.6.46-linux-glibc2.12-x86_64 mysql
cd mysql
echo 'Download completed !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!'

sudo chown -R mysql:mysql *

echo 'Installing.....................................................'
sudo apt-get install libaio1 libncurses5 -y

sudo scripts/mysql_install_db --user=mysql

sudo chown -R root .
sudo chown -R mysql data

sudo openssl genrsa -out private_key.pem 1024
sudo openssl rsa -in private_key.pem -pubout > public_key.pem
sudo chmod 400 private_key.pem
sudo chmod 444 public_key.pem
sudo chown mysql:mysql private_key.pem
sudo chown mysql:mysql public_key.pem

echo "Sha256_password_private_key_path=/path/to/my/key/mykey.pem" >> ./support-files/my-default.cnf
echo "Sha256_password_public_key_path=/path/to/my/pub/mykey.pub" >> ./support-files/my-default.cnf

sudo cp support-files/my-default.cnf /etc/my.cnf

echo 'starting mysql !!!!!!!!!!!!!'
sudo systemctl daemon-reload
sudo ./bin/mysqld_safe --user=mysql &
sudo cp support-files/mysql.server /etc/init.d/mysql.server

echo '~~~~~~~~~~~~[ Setting login: Username -> "root" ; Password -> "ares123" ]~~~~~~~~~~~~~~'
sudo ./bin/mysqladmin -u 'root' password 'ares123'
#sudo ./bin/mysqladmin -u root password ''
#sudo mysql -u root -e "SET PASSWORD FOR root@'localhost' = PASSWORD('');"

sudo ln -s /usr/local/mysql/bin/mysql /usr/local/bin/mysql
echo '--------> Added mysql path to system'

echo 'launching SQL Server.................................'
sudo /etc/init.d/mysql.server start

echo '---------------------------------------------------------------------------------------------'
echo 'Server Status: '
sudo /etc/init.d/mysql.server status
sleep 5

echo '>>>>>>>>>>>>>>>>>>>>>>>>>>> Enabling mySql on Startup >>>>>>>>>>>>>>>>>>>>>>>>'
sudo update-rc.d -f mysql.server defaults
echo 'Added to Startup'
fi
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
sudo apt update -y
echo '.............................................................................'
echo '.............................................................................'
echo '>>>>>>>>>>>>>>>>>>>>>>> Installing PhpMyAdmin >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>'

sudo apt install php5.6-mbstring -y
sudo apt install php5.6-gettext -y
sudo phpenmod mbstring
sudo /etc/init.d/lighttpd restart

cd /tmp
sudo rm -rf phpMyAdmin-4.9.10-english phpmyadmin
sudo wget https://files.phpmyadmin.net/phpMyAdmin/4.9.10/phpMyAdmin-4.9.10-english.tar.gz
sudo tar -xvf phpMyAdmin-4.9.10-english.tar.gz
sudo mv phpMyAdmin-4.9.10-english phpmyadmin
sudo mv phpmyadmin /var/www/html

echo 'phpmyadmin 4.9.10 version downloaded.......'

echo 'Updating Configuration files....................................'
cd $DIR_PATH
sudo cp ./ares/config.inc.php /var/www/html/phpmyadmin/config.inc.php

#sudo cat > $DIR_PATH/.my.cnf << EOF
#[client]
#user=root
#password=""

#[mysql]
#user=root
#password=""
#EOF

#mysql -h "server-name" -u "root" "-pXXXXXXXX" "database-name" < "filename.sql"
#sudo mysql -h "localhost" -e 
#sudo mysql -u root -e "CREATE USER 'root'@'localhost' IDENTIFIED BY 'ares123';"


sudo /etc/init.d/mysql.server stop
sudo mysqld_safe --skip-grant-tables --skip-syslog --skip-networking


sudo mysql -u'root' -p'ares123' -e "GRANT ALL PRIVILEGES ON *.* TO 'root'@'localhost' WITH GRANT OPTION;"
sudo mysql -u'root' -p'ares123' -e "FLUSH PRIVILEGES;"

echo 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'

MYSQL_PASSWORD="ares12345"

sudo sed -i 's/127.0.0.1/0.0.0.0/g' /etc/my.cnf
sudo sed -i '/\[mysqld\]/a\lower_case_table_names=1' /etc/my.cnf
echo "MySQL Password set to '${MYSQL_PASSWORD}' "
mysql -u'root' -p$MYSQL_PASSWORD -e "GRANT ALL ON *.* TO 'root'@'%' IDENTIFIED BY '$MYSQL_PASSWORD'; FLUSH PRIVILEGES;";

sudo service mysql start
sudo /etc/init.d/mysql.server restart
sudo /etc/init.d/mysql.server status


sudo cp -r ./ares/ares-main/* /var/www/html/
echo 'Configurations modified!!!!!!!!!!!!!!!!!!!!!!'
echo '.............................................................................'
echo 'Try to launch following pages:'
echo 'http://localhost'
echo 'http://localhost/info.php'
echo 'http://localhost/phpmyadmin'

read -p "Press any key to Exit > " -n1 junk
echo

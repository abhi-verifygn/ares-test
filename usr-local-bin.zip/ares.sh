#!/usr/bin/env bash

echo 'Initiating dependency installations......'
echo 'This script is designed purely for ubuntu 20.4.5 version'
echo 'Make sure your system version will match the specified version'
sudo lsb_release -a
echo ' '
echo '############################### '
echo 'use ctrl+z to abort the process'
sleep 5

sudo apt update
sudo apt install git -y
echo 'Git Installed....................................'
sudo apt install lighttpd
echo 'lighttpd Installed ..................................'



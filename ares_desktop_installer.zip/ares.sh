#!/usr/bin/env bash

echo 'Initiating dependency installations......'
echo 'This script is designed purely for ubuntu 20.04.5 version'
echo 'Make sure your system version will match the specified version'
echo '##############################################################'
sudo lsb_release -a
echo ' '
echo '############################################################## '
echo 'use "ctrl+z" or "ctrl+c" to abort the process'
sleep 5

sudo apt update
sudo apt install git -y
echo 'Git Installed....................................'
sudo apt install lighttpd -y
echo 'lighttpd Installed ..................................'

echo '>>>>>>>>>>>>>>>>>>>>>>>>>>>>  Installing php5  >>>>>>>>>>>>>>>>>>>>>>>>>>>'
sudo apt install php5-common -y
sudo apt install php5-cli -y
sudo apt install php5-cgi -y
sudo apt install php5-curl -y
sudo apt install php5-gd -y
sudo apt install php5-mysql -y
sudo apt install php5-xmlrpc -y
sudo apt install php5-pear -y

echo 'php5 and its extensions Installed Successfully...........................................'
read -p "Press any key to Exit > " -n1 junk
echo

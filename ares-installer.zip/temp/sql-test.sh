#!/usr/bin/env bash

MYSQL_PASSWORD="ares123"

sudo sed -i 's/127.0.0.1/0.0.0.0/g' /etc/my.cnf
sudo sed -i '/\[mysqld\]/a\lower_case_table_names=1' /etc/my.cnf
#echo "MySQL Password set to '${MYSQL_PASSWORD}'. Remember to delete ~/.mysql.passwd" | tee ~/.mysql.passwd; 
echo "MySQL Password set to '${MYSQL_PASSWORD}' "
mysql -uroot -p$MYSQL_PASSWORD -e "GRANT ALL ON *.* TO root@'%' IDENTIFIED BY '$MYSQL_PASSWORD'; FLUSH PRIVILEGES;";
sudo service mysql restart

#sudo mysql -h "localhost" -e 
#sudo mysql -u root -e "CREATE USER 'root'@'localhost' IDENTIFIED BY 'ares123';"
#sudo mysql -u root -e "FLUSH PRIVILEGES;"
#sudo mysql -u root -e "GRANT ALL PRIVILEGES ON *.* TO 'root'@'localhost' WITH GRANT OPTION;"
